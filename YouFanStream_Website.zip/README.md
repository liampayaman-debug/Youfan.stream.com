# 🎥 You Fan Stream

A sleek, modern fan-streaming web app where users can connect with creators, watch live content, message other fans, and unlock exclusive features through subscription plans.

## 🚀 Project Structure

| File | Description |
|------|--------------|
| index.html | Landing page for the You Fan Stream website. |
| home.html | Main dashboard showing featured and suggested content. |
| Login.html | Fansly-style login and signup interface with modals. |
| Message.html | Direct messaging interface between fans and creators. |
| Plan.html | Subscription plans (Pro, VIP, Grand) page. |
| Payment.html | Payment form for processing selected plans. |
| Profile.html | Creator profile page with exclusive posts and content previews. |

## 🧭 Navigation

- Start from **index.html**
- Sign in through **Login.html**
- After login, explore the home feed at **home.html**
- Visit creator profiles at **Profile.html**
- Use **Message.html** to chat with creators
- Upgrade via **Plan.html** and pay with **Payment.html**

## 💻 Technologies Used

- HTML5, CSS3, Tailwind CSS
- Vanilla JavaScript
- LocalStorage for temporary plan data
- Responsive design for mobile and desktop

## 🧠 Features

- 🎨 Fansly-style modern UI
- 💬 Direct fan-to-creator messaging
- 🪩 Premium plan purchase flow
- 🔥 Live and exclusive content previews
- 🪄 Smooth modal animations

## ⚙️ Setup

1. Place all files in the same directory.
2. Open `index.html` in your browser.
3. Navigate through linked pages.

## 🏁 Future Enhancements

- Add authentication backend (Firebase / Supabase)
- Integrate payment APIs (Stripe / PayPal)
- Enable media uploads
- Add real chat persistence

**Made with ❤️ by You Fan Stream Team**
